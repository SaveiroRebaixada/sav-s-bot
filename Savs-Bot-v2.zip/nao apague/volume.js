const { MessageEmbed } = require("discord.js");
const sendError = require("../util/error");

module.exports = {

    name: "volume",
    description: "To change the server song queue volume",
    usage: "[volume]",
    aliases: ["v", "vol"],


  execute: async function (message, client, args) {
    const channel = message.member.voice.channel;
    if (!channel)return sendError("Entre em um canal de voz!", message.channel);
    const serverQueue = message.client.queue.get(message.guild.id);
    if (!serverQueue) return sendError("Não está tocando nada.", message.channel);
    if (!serverQueue.connection) return sendError("Não está tocando nada.", message.channel);
    if (!args[0])return message.channel.send(`Volume atual: **${serverQueue.volume}**`);
     if(isNaN(args[0])) return message.channel.send(':notes: Use apenas numeros!').catch(err => console.log(err));
    if(parseInt(args[0]) > 150 ||(args[0]) < 0) return sendError('Você não pode setar o volume acima de 150 ou abaixo de 0',message.channel).catch(err => console.log(err));
    serverQueue.volume = args[0]; 
    serverQueue.connection.dispatcher.setVolumeLogarithmic(args[0] / 100);
    let xd = new MessageEmbed()
    .setDescription(`O volume agora é: **${args[0]/1}/100**`)
    .setAuthor("Server Volume Manager", "https://raw.githubusercontent.com/SudhanPlayz/Discord-MusicBot/master/assets/Music.gif")
    .setColor("BLUE")
    return message.channel.send(xd);
  },
};