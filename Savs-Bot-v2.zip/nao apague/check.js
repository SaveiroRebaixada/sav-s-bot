const Schema = require('../models/welcomeChannel')
const { Client, Message, MessageEmbed } = require('discord.js')

module.exports = {
  name: 'checkchannel',
  aliases: ["cc"],
  /**
   * @param {Client} client
   * @param {Message} message
   * @param {String[]} args
   */

  execute: async(message, client, args) => {
    if(message.member.permissions.has('ADMINISTRATOR')) return;

    Schema.findOne({ Guild: message.guild.id }, async(err,data) => {
      if(!data) return message.reply('este servidor nao possue data armazenada')
      
      const channel = client.channels.cache.get(data.Channel)

      message.reply(`Canal de boas vindas => ${channel}`)
    })
  }
}