module.exports = {
    name: 'ping',
    description: 'Latencia do bot',
    cooldown: 5,
    aliases: ['latency'],
    async execute(message, client) {
        const m = await message.channel.send(",,ping");
        m.edit(`A latência é ${m.createdTimestamp - message.createdTimestamp}ms.\nA latência da API é: ${Math.round(client.ws.ping)}ms`);
    },
};