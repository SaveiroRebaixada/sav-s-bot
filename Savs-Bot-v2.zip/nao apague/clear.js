const Discord = require('discord.js');
const message = require('../events/message');

module. exports = {

    name: "clear",
    aliases: ['limpar'],
    description: "Limpe mensagens",
    example: ",,clear",
    usage: ',,clear <quantia>',


        async execute (message, client, args)  {
        if(!message.member.hasPermission("MANAGE_MESSAGES")) return message.reply('Você não pode executar este comando!').then(m => m.delete({ timeout: 5000 }));
        if(!message.guild.me.hasPermission("MANAGE_MESSAGES")) return message.reply('Eu não pode executar este comando').then(m => m.delete({ timeout: 5000 }));

        let quantia = args[0]
        if (!quantia) return message.reply('Preciso saber a quantidade!').then(m => m.delete({ timeout: 5000 }));
        if (isNaN(quantia)) return message.reply('Use numeros!').then(m => m.delete({ timeout: 5000 }));

        if (parseInt(quantia) > 100 || parseInt(quantia) < 1) return message.reply('Apenas apago entre 1 e 100 mensagens...').then(m => m.delete({ timeout: 5000 }));
        
    const Embed = new Discord.MessageEmbed()
    Embed.setTitle('Comando executado!')
    Embed.setColor(`#48C9B0`)
    Embed.setDescription(`Foram apagadas ${quantia} mensagens.`)

        try {
            message.channel.bulkDelete(quantia)
            message.channel.send(Embed).then(m => m.delete({ timeout: 5000 }));
    } catch (err) {
        console.log(err);
        message.channel.send(`Houve um erro ao apagar mensagens!`).then(m => m.delete({ timeout: 5000 }));
    }

}
}


    