const Discord = require('discord.js');

const client = new Discord.Client();

module.exports = {
  config: {
    name: 'ban',
    description: "Banir usuarios",
    aliases: ['ban'],
    example: ",,ban @User#1000",
    usage: ",,ban <user>", 
  },

    async execute(message, client, args) {
      if(!message.member.hasPermission("BAN_MEMBERS")) return message.reply('comando restrito à staff');
      if(!message.guild.me.hasPermission("BAN_MEMBERS")) return message.reply('comando restrito à staff');

      let member = message.mentions.members.first() || message.guild.members.cache.get(args[1]);
      if (!member) return message.reply('Preciso saber o membro que você quer expulsar!');
      if (member === message.member) return message.reply('Você não pode se expulsar');

      let reason = args.slice(1).join(" ");
      if (!reason) return message.reply('expecifique o motivo');

      let channel = message.guild.channels.cache.get('801271286500163584')

      const Embed = new Discord.MessageEmbed()
      Embed.setTitle('Membro Banido')
      Embed.setColor(`#48C9B0`)
      Embed.setDescription(`Membro banido: ${member}\nMotivo: ${reason}`)
      Embed.setFooter(`${message.author.tag} | ${message.author.id}`, message.author.displayAvatarURL({ dynamic: true }));

      member.user.send(`Você foi mutado no servidor **Porão do Saveiro** permanentemente por ${reason}, converse com um Staff se ocorreu um mal entendido`)

      channel.send(Embed)
      member.ban()
    }
    


}
