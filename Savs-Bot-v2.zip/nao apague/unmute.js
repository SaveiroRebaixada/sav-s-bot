const Discord = require('discord.js')
module.exports = {
    name: 'unmute',
    Description: 'Desmutar membros',
    usage: ',,unmute <user>',

    async execute (message, client, args) {
        
        const target = message.mentions.users.first();
        if(!message.member.hasPermission("MUTE_MEMBERS")) return message.reply('comando restrito a staff');
        if(!message.guild.me.hasPermission("MUTE_MEMBERS")) return message.reply('comando restrito a staff');
        if(target){
            let mainRole = message.guild.roles.cache.find(role => role.name === 'Membros');
            let muteRole = message.guild.roles.cache.find(role => role.name === 'Muted')

            let memberTarget = message.guild.members.cache.get(target.id);

            const Embed = new Discord.MessageEmbed()
            Embed.setDescription(`<@${memberTarget.user.id}> Usuario desmutado!`)
            Embed.setColor(`#48C9B0`)
            Embed.setDescription(`Membro desmutado: <@${memberTarget.user.id}>`)
            

            memberTarget.roles.add(mainRole.id);
            memberTarget.roles.remove(muteRole.id);
            message.channel.send(Embed)

            const unmute = new Discord.MessageEmbed()
            unmute.setDescription(`<@${memberTarget.user.id}> Usuario desmutado!`)
            unmute.setColor(`#48C9B0`)
            unmute.setDescription(`Membro desmutado: <@${memberTarget.user.id}>`)
            unmute.setFooter(`${message.author.tag} | ${message.author.id}`, message.author.displayAvatarURL({ dynamic: true }));
  
            let channel = message.guild.channels.cache.get('801271286500163584')
            channel.send(unmute)

        } else {
            message.channel.send('Nao encontrei o usuario!');
        
        }
    }
}