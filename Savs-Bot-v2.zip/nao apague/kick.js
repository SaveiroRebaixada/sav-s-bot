const Discord = require('discord.js');

const client = new Discord.Client();

module.exports = {
  config: {
    name: 'kick',
    description: "Expulse usuarios",
    aliases: ['kick'],
    example: ",,kick @User#1000",
    usage: ",,kick <user>", 
  },

    async execute(message, client, args) {
      if(!message.member.hasPermission("KICK_MEMBERS")) return message.reply('Comando de staff!').then(m => m.delete({ timeout: 5000 }));
      if(!message.guild.me.hasPermission("KICK_MEMBERS")) return message.reply('Comando de staff!').then(m => m.delete({ timeout: 5000 }));

      let member = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
      if (!member) return message.reply('Preciso saber o membro que voce quer expulsar');
      if (member === message.member) return message.reply('você não pode se expulsar');

      let reason = args.slice(1).join(" ");
      if (!reason) return message.reply('expecifique o motivo');

      const Embed = new Discord.MessageEmbed()
      Embed.setTitle('Membro Expulso')
      Embed.setColor(`#48C9B0`)
      Embed.setDescription(`Membro expulso: ${member}\nMotivo: ${reason}`)
      Embed.setFooter(`${message.author.tag} | ${message.author.id}`, message.author.displayAvatarURL({ dynamic: true }));

      let channel = message.guild.channels.cache.get('801271286500163584')

      channel.send(Embed)
      member.kick()
    }
    


}

