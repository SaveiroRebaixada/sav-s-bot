const Discord = require('discord.js')

module.exports = { 

        async execute(message, client, args) {
        var list = [
            'https://imgur.com/gallery/2HitdsF.gif',
            'https://imgur.com/WVSwvm6.gif',
            'https://imgur.com/sZhtvBR.gif',
            'https://imgur.com/yP3W3pH.gif',
            'https://imgur.com/THyefKo.gif',
            'https://imgur.com/fXh0i2H.gif',
            'https://imgur.com/L0ujw2R.gif',
            'https://imgur.com/SS7sQpj.gif',
            'https://i.imgur.com/SeCRpPp.gif',
            'https://i.imgur.com/2pZMgU7.gif',
            'https://i.imgur.com/RZ6myag.gif',
            'https://media.tenor.com/images/6b3243e541ffe31a34a281c009e27fc4/tenor.gif',
            'https://media.tenor.com/images/42df922a869fad7b0ba95244c1ad12ac/tenor.gif',
            'https://media.tenor.com/images/a6e3e4b2bbeea78cb641c49e03c855b3/tenor.gif',
            'https://media.tenor.com/images/8ffcf186ca3cc791d302b415c62d503b/tenor.gif',
            'https://media.tenor.com/images/33fbd8d04e799c91ad5c17ff1e5a2088/tenor.gif',
            'https://media.tenor.com/images/924c9665eeb727e21a6e6a401e60183b/tenor.gif',
            'https://media.tenor.com/images/7b50048d76f76a8e5b3d8fc5a3fc6a21/tenor.gif',
            'https://media.tenor.com/images/dd777838018ab9e97c45ba34596bb8de/tenor.gif'
        ];
        var rand = list[Math.floor(Math.random() * list.length)];
        let user = message.mentions.users.first() || client.users.cache.get(args[0]);
        if (!user) {
            return message.reply('Mencione um membro do servidor!');

        }

        const embed = new Discord.MessageEmbed()
    .setColor(`#FF1493`)
    .setDescription(`${message.author} **deu um beijo em** ${user}💓`)
    .setImage(rand)
   
    
    await message.channel.send(embed) 

    }
}