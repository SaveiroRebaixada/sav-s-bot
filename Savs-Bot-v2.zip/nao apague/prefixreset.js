const prefixSchema = require('../models/prefix')
const prefix = require('../config.json')
const MessageEmbed = require('discord.js')
const { confirmation } = require('@reconlx/discord.js')
module.exports = {
  name: 'prefix-reset',

  execute: async(message, client) => {
    message.channel.send("Deseja mesmo resetar o prefixo?").then(async (msg) => {
      const emoji = await confirmation(msg, message.author, ['✔️', '❌'], 10000)
      if(emoji === '✔️') {
        msg.delete()
        await prefixSchema.findOneAndDelete({ Guild : message.guild.id })

      }
      if(emoji === '❌') {
        msg.delete()
        const cancelado = new MessageEmbed()
        .setTitle("Cancelando...")
        .setDescription("O prefixo esta inalterado e a acao foi cancelada")
        message.channel.send(`O prefixo foi alterado para ${prefix}`)
      }
    })
  }
}