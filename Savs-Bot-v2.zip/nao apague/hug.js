const Discord = require('discord.js')

module.exports = {

    async execute(message, client, args) {
        var list = [
        'https://i.imgur.com/XEs1SWQ.gif',
        'https://i.imgur.com/gSGeZJF.gif',
        'https://i.imgur.com/EatYxy1.gif',
        'https://i.imgur.com/snm8S1B.gif',
        'https://i.imgur.com/34Ldmbz.gif',
        'https://i.imgur.com/RPYNm9o.gif',
        'https://i.imgur.com/hA9ZNoR.gif',
        'https://i.imgur.com/iKPs2AJ.gif',
        'https://i.imgur.com/hgDeZLg.gif',
        'https://i.imgur.com/HQmTIos.gif',
        'https://i.imgur.com/KYwFHgK.gif',
        'https://i.imgur.com/hm9aSze.gif',
        'https://i.imgur.com/H2NWde0.gif',
        'https://i.imgur.com/QFU1X1p.gif',
        'https://i.imgur.com/hM0GKmI.gif',
        'https://i.imgur.com/kSWpxnG.gif',
        'https://i.imgur.com/bT766fG.gif',
        'https://i.imgur.com/2KuWGal.gif',
        'https://i.imgur.com/qQ70mcV.gif'
        ];
        var rand = list[Math.floor(Math.random() * list.length)];
        let user = message.mentions.users.first() || client.users.cache.get(args[0]);
        if (!user) {
            return message.reply('Mencione um membro do servidor!');

        }

        const embed = new Discord.MessageEmbed()
            .setColor(`#FF1493`)
            .setDescription(`${message.author} **deu um abraço em** ${user}💓`)
            .setImage(rand)


        await message.channel.send(embed)

    }
}