const { MessageEmbed } = require("discord.js");
const sendError = require("../util/error");

module.exports = {

        name: "leave",
        aliases: ["goaway", "disconnect"],
        description: "Leave The Voice Channel!",
        usage: "Leave",


    execute: async function (message, client, args) {
        let channel = message.member.voice.channel;
        if (!channel) return sendError("Você precisa estar em um canal de voz!", message.channel);
        if (!message.guild.me.voice.channel) return sendError("Eu não estou em um canal de voz!", message.channel);

        try {
            await message.guild.me.voice.channel.leave();
        } catch (error) {
            await message.guild.me.voice.kick(message.guild.me.id);
            return sendError("Saindo do canal de voz...", message.channel);
        }

        const Embed = new MessageEmbed()
            .setAuthor("Saindo do canal de voz", "https://raw.githubusercontent.com/SudhanPlayz/Discord-MusicBot/master/assets/Music.gif")
            .setColor("GREEN")
            .setTitle("Comando executado")
            .setDescription("🎶 Sai do canal de voz.")
            .setTimestamp();

        return message.channel.send(Embed).catch(() => message.channel.send("🎶 Estou fora do canal de voz :("));
    },
};