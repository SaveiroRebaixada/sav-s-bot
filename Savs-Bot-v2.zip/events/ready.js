const { MessageEmbed } = require("discord.js")

const Discord = require('discord.js')

module.exports = async (client) => {


    console.log(`Eu estou online agora, meu nome é ${client.user.tag}, Há ${client.users.size} usuario(s) em ${client.guilds.size} servidor(es)!`)
    console.log('events ativos')
    console.log('commands ativos')
    client.user.setPresence({
      status: 'streaming',
      game: {
        name: process.env.GAME
      }
    })
  }