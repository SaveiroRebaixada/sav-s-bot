const Schema = require('../models/byeChannel')
const { MessageEmbed } = require('discord.js')
const imageSchema = require('../models/setimagebye')

module.exports = async (message, member) => {

  const idata = await imageSchema.findOne({ Guild: member.guild.id })
    .catch(err => console.log(err))
    if(!idata) return;

  const image = (idata.Image)

    const data = await Schema.findOne({ Guild: member.guild.id })
    .catch(err => console.log(err))
    if(!data) return;

    const user = member.user;

    const bye = new MessageEmbed()
    .setTitle('Adeus :/')
    .setThumbnail(`${user.displayAvatarURL()}`)
    .setDescription(`**Adeus ${user.username} esperamos a sua volta por aqui :D**`)
    .setColor("BLUE")
    .setImage(image)
    .setFooter(`${user.username} | ${user.id}`)
  
    const channel = member.guild.channels.cache.get(data.Channel);
    channel.send(bye)
}

