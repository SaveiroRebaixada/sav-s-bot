const { prefix } = require("../config.json");
const { Collection } = require("discord.js");

const cooldowns = new Collection();

module.exports = async (client, message) =>{
  const p = await client.prefix(message)

 
	if (!message.content.startsWith(p) || message.author.bot || message.channel.type === "dm") return;
    const args = message.content.slice(p.length).trim().split(/ +/);
	const commandName = args.shift().toLowerCase();
	
    const command = client.commands.get(commandName) || client.commands.find(cmd => cmd.aliases && cmd.aliases.includes(commandName));
    
    if (!command) return;

	if (command.guildOnly && message.channel.type === 'dm') {
		return message.reply('I can\'t execute that command inside DMs!');
	}

	if (command.permissions) {
		const authorPerms = message.channel.permissionsFor(message.author);
		if (!authorPerms || !authorPerms.has(command.permissions)) {
			return message.reply('Voce não tem permissão!');
        }
    }
    if (command.args && !args.length) {
		let reply = `Você não forneceu nenhum argumento, ${message.author}!`;

		if (command.usage) {
			reply += `\nO uso adequado seria: \`${prefix}${command.name} ${command.usage}\``;
		}

		return message.channel.send(reply);
	}

	if (!cooldowns.has(command.name)) {
		cooldowns.set(command.name, new Collection());
	}

	const now = Date.now();
	const timestamps = cooldowns.get(command.name);
	const cooldownAmount = (command.cooldown || 3) * 1000;

	if (timestamps.has(message.author.id)) {
		const expirationTime = timestamps.get(message.author.id) + cooldownAmount;

		if (now < expirationTime) {
			const timeLeft = (expirationTime - now) / 1000;
			return message.reply(`Espere ${timeLeft.toFixed(1)} segundos para executar o comando \`${command.name}\``);
		}
	}

	timestamps.set(message.author.id, now);
	setTimeout(() => timestamps.delete(message.author.id), cooldownAmount);

	try {
		command.execute(message, client, args);
	} catch (error) {
		console.error(error);
		message.reply('erro executando esse comando!');
	}

 
const prefixSchema = require('../models/prefix')

client.on('guildDelete', async (guild) => {
    prefixSchema.findOne({ Guild: guild.id }, async (err, data) => {
        if (err) throw err;
        if (data) {
            prefixSchema.findOneAndDelete({ Guild : guild.id }).then(console.log('deleted data.'))
        }

       

})

    })


}

