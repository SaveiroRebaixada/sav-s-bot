const Schema = require('../models/welcomeChannel')
const { MessageEmbed } = require('discord.js')
const imageSchema = require('../models/setimage')

module.exports = async (message, member) => {

  const idata = await imageSchema.findOne({ Guild: member.guild.id })
    .catch(err => console.log(err))
    if(!idata) return;

  const image = (idata.Image)

    const data = await Schema.findOne({ Guild: member.guild.id })
    .catch(err => console.log(err))
    if(!data) return;

    const user = member.user;

    const welcome = new MessageEmbed()
    .setTitle('Boas-Vindas!')
    .setThumbnail(`${user.displayAvatarURL()}`)
    .setDescription(`**Olá ${user} seja muito bem vindo ao meu servidor, espero que aproveite a estadia!\nNão se esqueça de ler as regras**`)
    .setColor("BLUE")
    .setImage(image({ Dynamic: true }))
    .setFooter(`${user.username} | ${user.id}`)
  
    const channel = member.guild.channels.cache.get(data.Channel);
    channel.send(welcome)
}

