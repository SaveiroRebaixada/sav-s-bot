const { MessageEmbed } = require("discord.js");
const sendError = require("../../util/error");

module.exports = {

    name: "remove",
    description: "Remove song from the queue",
    usage: "rm <number>",
    aliases: ["rm"],


  execute: async function (message, client, args) {
   const queue = message.client.queue.get(message.guild.id);
    if (!queue) return sendError("Não existe essa musica na queue.",message.channel).catch(console.error);
    if (!args.length) return sendError(`Usage: ${client.config.prefix}\`remove <Queue numero>\``);
    if (isNaN(args[0])) return sendError(`Usage: ${client.config.prefix}\`remove <Queue numero>\``);
    if (queue.songs.length == 1) return sendError("Não está na queue.",message.channel).catch(console.error);
    if (args[0] > queue.songs.length)
      return sendError(`Queue tem apenas ${queue.songs.length} musicas!`,message.channel).catch(console.error);
try{
    const song = queue.songs.splice(args[0] - 1, 1); 
    sendError(`❌ **|** Removi **\`${song[0].title}\`** da queue.`,queue.textChannel).catch(console.error);
                   message.react("✅")
} catch (error) {
        return sendError(`:notes: An unexpected error occurred.\nPossible type: ${error}`, message.channel);
      }
  },
};