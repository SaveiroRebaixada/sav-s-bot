const { MessageEmbed } = require("discord.js");
const sendError = require("../../util/error");
const util = require("../../util/pagination");

module.exports = {

        name: "queue",
        description: "To show the server songs queue",
        usage: "",
        aliases: ["q", "list", "songlist", "song-list"],

    execute: async function (message, client, args) {
        const permissions = message.channel.permissionsFor(message.client.user);
        if (!permissions.has(["MANAGE_MESSAGES", "ADD_REACTIONS"])) return sendError("Missing permission to manage messages or add reactions", message.channel);

        const queue = message.client.queue.get(message.guild.id);
        if (!queue) return sendError("There is nothing playing in this server.", message.channel);

        const que = queue.songs.map((t, i) => `\`${++i}.\` | [\`${t.title}\`](${t.url}) - [<@${t.req.id}>]`);

        const chunked = util.chunk(que, 10).map((x) => x.join("\n"));

        const embed = new MessageEmbed()
            .setAuthor("Musicas da Queue list", "https://raw.githubusercontent.com/SudhanPlayz/Discord-MusicBot/master/assets/Music.gif")
            .setThumbnail(message.guild.iconURL())
            .setColor("BLUE")
            .setDescription(chunked[0])
            .addField("Tocando agora", `[${queue.songs[0].title}](${queue.songs[0].url})`, true)
            .addField("Canal de texto", queue.textChannel, true)
            .addField("Canal de voz", queue.voiceChannel, true)
            .setFooter(`Volume atual: ${queue.volume} Pagina 1 de ${chunked.length}.`);
        if (queue.songs.length === 1) embed.setDescription(`Sem musicas para tocar após essa, adicione mais usando: \`\`${message.client.p}play <nome_da_musica>\`\``);

        try {
            const queueMsg = await message.channel.send(embed);
            if (chunked.length > 1) await util.pagination(queueMsg, message.author, chunked);
        } catch (e) {
            msg.channel.send(`An error occured: ${e.message}.`);
        }
    },
};