const { MessageEmbed } = require("discord.js");
const sendError = require("../../util/error");

module.exports = {

    name: "pause",
    description: "To pause the current music in the server",
    usage: "[pause]",
    aliases: ["pause"],


  execute: async function (message, client, args) {
    const serverQueue = message.client.queue.get(message.guild.id);
    if (serverQueue && serverQueue.playing) {
      serverQueue.playing = false;
	    try{
      serverQueue.connection.dispatcher.pause()
	  } catch (error) {
        message.client.queue.delete(message.guild.id);
        return sendError(`:notes: O player foi parado e a Queue list foi limpa.: ${error}`, message.channel);
      }	    
      let xd = new MessageEmbed()
      .setDescription("⏸ Pausando a musica para você!")
      .setColor("YELLOW")
      .setTitle("Sua musica foi pausada!")
      return message.channel.send(xd);
    }
    return sendError("Nada está tocando atualmente.", message.channel);
  },
};