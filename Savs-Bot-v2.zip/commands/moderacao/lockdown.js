const Discord = require("discord.js");
const { MessageEmbed } = require("discord.js");

module.exports = {
  async execute(message, client, args) {
    const role = await message.guild.roles.cache.find(
      (r) => r.id === "777308432847470652"
    );
    const sender = message.author;

    if (
      !message.member.roles.cache.some((r) =>
        [
          "777299087904604220",
          "795834334015782944",
          "784609408713752617",
          "777299584556859404",
          "780081281571749898",
        ].includes(r.id)
      )
    ) {
      return message.channel.send(`${sender} comando restrito à staff`);
    } else if (message.content.includes("on")) {
      await role.setPermissions(1115137);

      const embed = new MessageEmbed()
        .setTitle("Lockdown Ativo")
        .setColor("#48C9B0")
        .setDescription(`Executado por ${sender}`);

      await message.channel.send(embed);
    } else if (message.content.includes("off")) {
      await role.setPermissions(70372417);

      const embedoff = new MessageEmbed()
        .setTitle("Lockdown Desabilitado")
        .setColor("#48C9B0")
        .setDescription(`Executado por ${sender}`);

      await message.channel.send(embedoff);
    } else {
      return message.channel.send(`${sender} Use **,,lockdown on | off**!!!`);
    }
  },
};
