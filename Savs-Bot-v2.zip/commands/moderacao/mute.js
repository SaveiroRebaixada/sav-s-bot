const ms = require('ms')
const Discord = require('discord.js')

module.exports = {
    name: 'mute',
    Description: 'Mutar membros',
    usage: ',,mute <user>',

    async execute(message, client, args) {
        
        const target = message.mentions.users.first() || message.guild.members.cache.get(args[0]);
        if (!message.member.hasPermission("MUTE_MEMBERS")) return message.reply('Comando restrito à staff');
        if (!message.guild.me.hasPermission("MUTE_MEMBERS")) return message.reply('Comando restrito à staff');
        if (target) {
            let mainRole = message.guild.roles.cache.find(role => role.name === 'Membros');
            let muteRole = message.guild.roles.cache.find(role => role.name === 'Muted')

            let reason = args.slice(1).join(" ");
      if (!reason) return message.reply('especifique o motivo');

            let memberTarget = message.guild.members.cache.get(target.id);

            if (!args[1]) {
                memberTarget.roles.remove(mainRole.id);
                memberTarget.roles.add(muteRole.id);
                message.channel.send(`<@${memberTarget.user.id}> Usuário mutado!`)
                return
            }

            memberTarget.roles.remove(mainRole.id);
            memberTarget.roles.add(muteRole.id);

            

            const Embed = new Discord.MessageEmbed()
            Embed.setColor('#00ac90')
            Embed.setDescription(`<@${memberTarget.user.id}> foi mutado por${ms(ms(args[1]))}\nMotivo: ${reason}`)
            message.channel.send(Embed)

            const log = new Discord.MessageEmbed()
        log.setTitle('Membro mutado')
        log.setColor(`#48C9B0`)
        log.setDescription(`Membro mutado: <@${memberTarget.user.id}>\nMotivo: ${reason}`)
        log.setFooter(`${message.author.tag} | ${message.author.id}`, message.author.displayAvatarURL({ dynamic: true }));
  
        let channel = message.guild.channels.cache.get('801271286500163584')
        channel.send(log)

            memberTarget.user.send(`Você foi mutado no servidor **Porão do Saveiro** por *(Tempo/Motivo)*: **${reason}**`)

            setTimeout(function () {
                memberTarget.roles.remove(muteRole.id);
                memberTarget.roles.add(mainRole.id);  
            }, ms(args[1]))
        } else {
            const nf = new Discord.MessageEmbed()
            nf.setColor('#00ac90')
            nf.setDescription(`Usuário não encontrado!`)
            message.channel.send(nf);

        }
        
    }
}