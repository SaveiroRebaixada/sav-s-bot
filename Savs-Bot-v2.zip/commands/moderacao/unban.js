const { MessageEmbed } = require('discord.js');

module.exports = {
    name: 'unban',
        async execute(message, client, args)  {

        if (!message.member.hasPermission('BAN_MEMBERS')) return message.channel.send('Voce precisa de **BAN_MEMBERS** permission!').then(m => m.delete({ timeout: 5000 }));

        if (!args[0]) return message.channel.send('Insira um ID de usuario!').then(m => m.delete({ timeout: 5000 }));

        let member;

        try {
            member = await client.users.fetch(args[0])
        } catch (e) {
            console.log(e)
            return message.channel.send('Usuario invalido!').then(m => m.delete({ timeout: 5000 }));
        }

        const reason = args[1] ? args.slice(1).join(' ') : 'no reason';

        const embed = new MessageEmbed()
            .setFooter(`${message.author.tag} | ${message.author.id}`, message.author.displayAvatarURL({ dynamic: true }));

        message.guild.fetchBans().then( bans => {

            const user = bans.find(ban => ban.user.id === member.id );

            if (user) {
                embed.setTitle(`Usuario desbanido ${user.user.tag}`)
                    .setColor('#8d04bd')
                    .addField('ID do usuario', user.user.id, true)
                    .addField('Tag do usuario', user.user.tag, true)
                    .addField('Motivo do ban', user.reason != null ? user.reason : 'no reason')
                    .addField('Motivo do Unban', reason)
                    let channel = message.guild.channels.cache.get('801271286500163584')

                message.guild.members.unban(user.user.id, reason).then(() => channel.send(embed))
            } else {
                embed.setTitle(`User ${member.tag} Não está banido!`)
                    .setColor('#8d04bd')
                message.channel.send(embed)
            }

        }).catch(e => {
            console.log(e)
            message.channel.send('Um erro ocorreu!')
        });
    }
  }