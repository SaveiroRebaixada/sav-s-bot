const imgSchema = require('../../models/setimage')
const { Client, Message, MessageEmbed } = require('discord.js')

module.exports = {
  name: 'setimage',
  aliases: ['imagewelcome', 'iw'],
  /**
   * @param {Client} client
   * @param {Message} message
   * @param {String[]} args
   */

  execute: async(message, client, args) => {
    if(!message.member.permissions.has('ADMINISTRATOR')) return;

     const img = await args.join(" ")
        if(!img) return message.channel.send('Insira o link da imagem ou gif por favor.')
        imgSchema.findOne({ Guild : message.guild.id }, async(err, data) => {
            if(err) throw err;
            if(data) {
                imgSchema.findOneAndUpdate({ Guild : message.guild.id })
                data = new imgSchema({
                    Guild : message.guild.id,
                    Image : img
                })
                data.save()
                message.channel.send(`Sua imagem foi definida como imagem do canal de boas vindas`)
            } else {
                data = new imgSchema({
                    Guild : message.guild.id,
                    Image: img
                })
                data.save()
                message.channel.send(`imagem foi definida`)
            }
        })
    }
}