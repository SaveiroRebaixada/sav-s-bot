const Schemawelcome = require('../../models/welcomeChannel')
const { Client, Message, MessageEmbed } = require('discord.js')

module.exports = {
  name: 'deletewelcomechannel',
  aliases: ['welcomechannel', 'dwc'],
  /**
   * @param {Client} client
   * @param {Message} message
   * @param {String[]} args
   */

  execute: async(message, client) => {
      if(!message.member.permissions.has('ADMINISTRATOR')) return;

        await Schemawelcome.findOneAndDelete({ Guild : message.guild.id })
        message.reply(`O canal de boas vindas foi desativado`)
      
  }
}