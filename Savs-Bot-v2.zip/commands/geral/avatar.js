const {MessageEmbed} = require('discord.js')

module.exports= {
    name: "avatar",
    description: "Veja seu avatar ou de qualquer pessoa",
    usage: ",,avatar <user>",
    
     async execute (message, client, args) {
         
        let Embed = new MessageEmbed()
        if(!message.mentions.users.first()){
            Embed.setTitle('Link para Download!')
            Embed.setURL(message.author.displayAvatarURL())
            Embed.setDescription('\```Aqui esta seu avatar!\```')
            Embed.setImage(message.author.displayAvatarURL()) 
            Embed.setTimestamp()
            Embed.setFooter(`${message.author.tag} | ${message.author.id}`, message.author.displayAvatarURL({ dynamic: true }))
            Embed.setColor(`#0056b3`)
            
            return message.channel.send(Embed)
       
        }else{
            let User = message.mentions.users.first()
            Embed.setTitle(`Link do Avatar de ${User.tag}`)
            Embed.setURL(User.displayAvatarURL())
            Embed.setDescription('\```Aqui esta seu avatar!\```')
            Embed.setImage(User.displayAvatarURL())
            Embed.setColor(`#0056b3`)
            Embed.setTimestamp()
            Embed.setFooter(`${message.author.tag} | ${message.author.id}`, message.author.displayAvatarURL({ dynamic: true }))
            
            return message.channel.send(Embed)
        }
    }
}