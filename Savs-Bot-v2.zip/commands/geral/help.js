const { ReactionPages } = require('reconlx')
const { MessageEmbed } = require('discord.js')

module.exports = {
    name: 'ajuda',
    async execute(message, client, args) {
        const utilidades = new MessageEmbed()
        .setTitle('**Utilidades**')
        .setColor('#0027ff')
        .addFields(
            {
                name: '\```,,avatar\```',
                value: 'Mostra seu avatar ou de alguma pessoa que tenha sido mencionada\nExemplo de uso: **,,avatar @user#1000**',
                
            },
            {
                name: '\```,,ping\```',
                value: 'Veja a latencia do bot\nExemplo de uso: **,,ping**',
               
            },
            {
                name: '\```,,serverinfo\```',
                value: 'Veja Informações sobre o servidor\nExemplo de uso: **,,serverinfo**',
            },
            {
                name: '\```,,userinfo\```',
                value: 'Mostra Informações sobre algum usuário mencionado\nExemplo de uso: **,,userinfo @user#1000**',
                
            },
        )
        const Moderação = new MessageEmbed()
        .setTitle('**Moderação**')
        .setColor('#006dff')
        .addFields(
            {
                name: '\```,,ban\```',
                value: 'Bana usuarios permanentemente\nExemplo de uso: **,,ban @user#1000 [motivo]**',
                inline: true
            },
            {
                name: '\```,,unban\```',
                value: 'Retire o ban de usuarios\nExemplo de uso: **,,unban @user#1000**',
                inline: true
            },
            {
                name: '\```,,clear\```',
                value: 'Exclua mensagens com apenas um comando\nExemplo de uso: **,,clear [Valor entre 1 e 100]**',
                inline: true
            },
            {
                name: '\```,,kick\```',
                value: 'Expulse usuarios (permite que o usuario volte com um convite)\nExemplo de uso: **,,kick @user#1000 [motivo]**',
                inline: true
            },
            {
                name: '\```,,mute\```',
                value: 'Mute usuarios com tempo definido\nExemplo de uso: **,,ban @user#1000 [defina o tempo aqui}][motivo]**',
                inline: true
            },
            {
                name: '\```,,unmute\```',
                value: 'Retire o mute de usuarios\nExemplo de uso: **,,unmute @user#1000**',
                inline: true
            },
            {
                name: '\```,,warn\```',
                value: 'Envie um aviso para a DM de um usuario\nExemplo de uso: **,,warn @user#1000 [mensagem do aviso]**',
                inline: true
            }
        )
        const Diversão = new MessageEmbed()
        .setTitle('Diversão')
        .setColor('#00ceff')
        .addFields(
            {
                name: '\```,,hug\```',
                value: 'Mencione um usuario para abraçar\nExemplo de uso: **,,hug @user#1000**',
            },
            {
                name: '\```,,kiss\```',
                value: 'Mencione um usuario para beija-lo\nExemplo de uso: **,,kiss @user#1000**',
            }
        )
            const pages = [utilidades, Moderação, Diversão]
            ReactionPages(message, pages, false)
    }
}