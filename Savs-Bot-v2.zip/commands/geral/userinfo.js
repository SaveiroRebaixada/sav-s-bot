const { MessageEmbed } = require('discord.js')
module.exports = {
    name: 'userinfo',
    
    async execute(message, client, args) {
        let user = message.mentions.members.first() || message.guild.members.cache.get(args[0]) || message.member;

        let status;
        switch (user.presence.status) {
            case "online":
                status = "online";
                break;
            case "dnd":
                status = "dnd";
                case "idle":
                    status = "idle";
                    break;
                case "offline":
                    status = "offline"
                    break;

        }

        const embed = new MessageEmbed()
        .setColor('#00c6ff')
        .setTitle(`${user.user.username}`)
        .setThumbnail(user.user.displayAvatarURL())
        .addFields(
            {
               name: "Nome: ",
               value: user.user.username 
            },
            {
                name: "#️⃣Tag numerica: ",
                value: user.user.discriminator,
            },
            {
                name: "🆔ID",
                value: user.user.id,
            },
            {
                name: "Status Atual: ",
                value: status,
            },
            {
                name: "Atividade: ",
                value: user.presence.activities[0] ? user.presence.activities[0].name : `Nao esta jogando nada`,
            },
            {
             name: 'Criado em: ',
             value: user.user.createdAt,   
            },
            {
                name: 'Entrou em: ',
                value: user.joinedAt,
            },
            {
                name: 'Cargos',
                value: user.roles.cache.map(role => role.toString()).join(","),
            }
        )
        await message.channel.send(embed)

    }
}