const Discord = require('discord.js');

module.exports = {

    name: "serverinfo",
    description: "mostra informacoes do servidor",
    usage: ",,serverinfo",

    async execute (message, client, args) {
        let emojis = message.guild.emojis.cache
        let texto = message.guild.channels.cache.filter(ch => ch.type === 'text')
        let voz = message.guild.channels.cache.filter(bh => bh.type === 'voice')

    const Embed = new Discord.MessageEmbed()
    Embed.setTitle(`Infos do servidor ${message.guild.name}`)
    Embed.setThumbnail(message.guild.iconURL({ dynamic: true}))
    Embed.setColor(`#f501d6`)
    Embed.addField(`Nome:`, `${message.guild.name}`)
    Embed.addField(`Dono:`, `${message.guild.owner}`)
    Embed.addField(`ID:`, `${message.guild.id}`)
    Embed.addField(`Membros:`, `${message.guild.memberCount}`)
    Embed.addField(`Emojis:`, `${emojis.size}`)
    Embed.addField(`Canais de texto:`, `${texto.size}`)
    Embed.addField(`Canais de voz:`, `${voz.size}`)
    Embed.setFooter(`${message.author.tag} | ${message.author.id}`, message.author.displayAvatarURL({ dynamic: true }))

    message.channel.send(Embed)
    }

}