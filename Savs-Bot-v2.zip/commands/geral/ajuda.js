
const { MessageEmbed } = require('discord.js')
const { confirmation } = require('@reconlx/discord.js')
module.exports = {
  name: 'help',
  aliases: ["prefixreset", "resetprefix", "resetarprefixo"],

  execute: async(message, client) => {

    const teste = new MessageEmbed()
    .setTitle("Clica puta")

    const ds = new MessageEmbed()
    .setTitle("157 os mlk ta meck")
    message.channel.send("teste").then(async (msg) => {
      const emoji = await confirmation(msg, message.author, ['<:config:828787362397028352>', '❌'], 10000)
      if(emoji === '<:config:828787362397028352>') {
        msg.edit("cala boca puta")

      }
      if(emoji === '') {
        msg.edit('Anarcocapitalismo') 
      }
      if(emoji === '❌') {
        msg.delete()
        const cancelado = new MessageEmbed()
        .setTitle("Cancelando...")
        .setDescription("O prefixo esta inalterado e a acao foi cancelada")
        message.channel.send(`O prefixo foi alterado para ${prefix}`)
      }
    })
  }
}