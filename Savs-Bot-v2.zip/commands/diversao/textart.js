const { Client, Message, MessageEmbed } = require("discord.js");
const figlet = require('figlet');

module.exports = {
  name: "textart",
  aliases: ["asciitext", "textart", "arttext"],

  /**
   * @param {Client} client
   * @param {Message} message 
   * @param {String[]} args
   */

  async execute(message, client, args) {
    figlet.text(args.join(" "),
    { 
    font: "Doom",
  },
   async(err,data) => {
    message.channel.send(`\`\`\`${data}\`\`\`\``)
  })
  }
}