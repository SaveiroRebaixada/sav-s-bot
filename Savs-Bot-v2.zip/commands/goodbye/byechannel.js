const Schema = require('../../models/byeChannel')
const { Client, Message, MessageEmbed } = require('discord.js')

module.exports = {
  name: 'setbyechannel',
  aliases: ['byechannel', 'sbc'],
  /**
   * @param {Client} client
   * @param {Message} message
   * @param {String[]} args
   */

  execute: async(message, client, args) => {
    if(!message.member.permissions.has('ADMINISTRATOR')) return;

    const channel = message.mentions.channels.first();

    Schema.findOne({ Guild: message.guild.id }, async(err,data) => {

      if(data) {
        data.Channel = channel.id;
        data.save
      } else {
        new Schema({
          Guild: message.guild.id,
          Channel: channel.id,
        }).save();
      }
      message.reply(`${channel} foi definido como canal de despedidas`)
    })
  }
}