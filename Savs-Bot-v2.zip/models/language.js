const mongo = require('mongoose')

const Schema = new mongo.Schema({
  Guild: String,
  Language: String,
});

module.exports = mongo.model('set-lang', Schema);