const mongo = require('mongoose')

const Schema = new mongo.Schema({
  Guild: String,
  Image: String,
});

module.exports = mongo.model('set-image-bye', Schema);